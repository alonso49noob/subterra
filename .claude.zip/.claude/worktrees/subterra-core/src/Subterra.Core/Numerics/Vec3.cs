namespace Subterra.Core.Numerics
{
    // Empty for now; the real 3D vector arrives with the math primitives task.
    public readonly struct Vec3
    {
    }
}
