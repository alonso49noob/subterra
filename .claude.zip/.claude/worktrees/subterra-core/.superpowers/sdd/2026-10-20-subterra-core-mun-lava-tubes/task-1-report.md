# Task 1 report: Solution and core test project scaffolding

Status: DONE (with one forward-looking note, see Concerns)

Commit: `92d81df chore: scaffold Subterra solution` (branch `worktree-subterra-core`)

## What was implemented

- `Directory.Build.props`: same shape as proj4, with `KSPRefDir` (default: Steam install, read-only reference), `KSPTestDir` (default `C:\KSP_SubterraTest`), `KSPManaged`, `HarmonyDll`, net472, LangVersion 9.0, Nullable disabled. Both `KSPRefDir`/`KSPTestDir` are overridable by env var (MSBuild properties are case-insensitive).
- `src/Subterra.Core/Subterra.Core.csproj`: AssemblyName/RootNamespace `Subterra.Core`, no references. `src/Subterra.Core/Math/Vec3.cs`: `namespace Subterra.Core.Math { public readonly struct Vec3 { } }` (empty; Task 7 fills it in).
- `src/Subterra/Subterra.csproj`: proj4's reference set plus `UnityEngine.ImageConversionModule` (all `Private=false`), project reference to Core, `DeployMod` target (AfterTargets=Build) copying `Subterra.dll` + `Subterra.Core.dll` to `GameData/Subterra/Plugins/` (repo-relative). No deploy-to-KSP target exists. Placeholder `src/Subterra/AssemblyMarker.cs` (empty internal static class).
- `src/Subterra.DevTools/Subterra.DevTools.csproj`: same refs, references Subterra and Subterra.Core projects, `DeployDevTools` target copies only its own DLL to `build/DevTools/Subterra.DevTools/Plugins/`. Placeholder `src/Subterra.DevTools/AssemblyMarker.cs`.
- `tests/Subterra.Core.Tests/Subterra.Core.Tests.csproj`: Microsoft.NET.Test.Sdk 17.11.1, xunit 2.9.2, xunit.runner.visualstudio 2.8.2, references Core.
- `tests/Subterra.Core.Tests/SmokeTests.cs`: `CoreAssemblyHasNoUnityReference` (as in the brief, using `Assert.DoesNotContain(referenced, a => a.Name.StartsWith("UnityEngine"))`).
- `Subterra.sln`: generated with `dotnet new sln --format sln` (SDK 10 defaults to `.slnx`, which the brief did not ask for); `src` and `tests` solution folders.
- `.gitignore`: appended `.claude/`, existing entries kept.

## Verification

- RED: with the solution and test in place but no `Vec3`, `dotnet test tests/Subterra.Core.Tests -c Release` failed to compile: `SmokeTests.cs(12,51): error CS0234: 'Math' does not exist in namespace 'Subterra.Core'`.
- GREEN: after adding `Vec3.cs`: `Correctas! - Con error: 0, Superado: 1, Omitido: 0, Total: 1 - Subterra.Core.Tests.dll (net472)`.
- `dotnet build Subterra.sln -c Release --no-incremental`: 0 Advertencia(s), 0 Errores (all 4 projects).
- `dotnet test Subterra.sln -c Release` (full suite): 1 passed, 0 failed.
- Output copies confirmed: `GameData/Subterra/Plugins/Subterra.dll`, `GameData/Subterra/Plugins/Subterra.Core.dll`, `build/DevTools/Subterra.DevTools/Plugins/Subterra.DevTools.dll`; all git-ignored (not in `git status`).
- `Subterra.Core.dll` referenced assemblies (via reflection): `mscorlib` only.
- No file in the KSP install is newer than the repo files created (nothing written there).

## Files changed

`.gitignore` (M), `Directory.Build.props`, `Subterra.sln`, `src/Subterra.Core/Subterra.Core.csproj`, `src/Subterra.Core/Math/Vec3.cs`, `src/Subterra/Subterra.csproj`, `src/Subterra/AssemblyMarker.cs`, `src/Subterra.DevTools/Subterra.DevTools.csproj`, `src/Subterra.DevTools/AssemblyMarker.cs`, `tests/Subterra.Core.Tests/Subterra.Core.Tests.csproj`, `tests/Subterra.Core.Tests/SmokeTests.cs`.

## Self-review

- Removed an unused `using System.Linq;` from SmokeTests before committing.
- Placeholders are minimal (empty internal static classes); a later task can delete `AssemblyMarker.cs` in each project once real code exists.
- Git prints LF->CRLF warnings (`core.autocrlf=true` on this machine); benign.

## Concerns

- Namespace `Subterra.Core.Math` shadows `System.Math` for any code inside namespace `Subterra.Core.*` (and `Subterra.Core.Tests`): there, `Math.Sqrt(x)` binds `Math` to the namespace and fails with CS0234/CS0118. Later core tasks (Vec3, Noise, SDF, ...) will need `System.Math.Sqrt(...)`, a `using M = System.Math;` alias, or `global::System.Math`. Not changed here because the brief and plan fix the namespace verbatim.
- The brief says the smoke test only checks that the compiled assembly has no UnityEngine reference; with the placeholder core this passes trivially, and it only becomes meaningful as real code lands (the C# compiler only emits references for assemblies actually used).
- The plugin and DevTools assemblies currently reference no other assembly than mscorlib for the same reason, so the Unity/Harmony HintPaths are only proven to resolve (no MSB3245 warnings), not to bind at runtime.

---

# Fix round 1: rename Math namespace to Numerics, harden smoke test

Commit: `5256d0d refactor: rename core Math namespace to Numerics`

## What changed

- `git mv src/Subterra.Core/Math src/Subterra.Core/Numerics`; `Vec3.cs` now declares `namespace Subterra.Core.Numerics`, so `System.Math` is no longer shadowed inside `Subterra.Core.*`. A grep for `Core.Math` over `.cs`, `.csproj` and `.sln` finds no remaining references.
- `SmokeTests.cs` uses `typeof(Subterra.Core.Numerics.Vec3)` and the assertion now also rejects KSP: `a => a.Name.StartsWith("UnityEngine") || a.Name.StartsWith("Assembly-CSharp")`.

## Commands and output

- `dotnet build Subterra.sln -c Release` -> `Compilacion correcta. 0 Advertencia(s) 0 Errores` (all 4 projects).
- `dotnet test tests/Subterra.Core.Tests -c Release` -> `Correctas! - Con error: 0, Superado: 1, Omitido: 0, Total: 1 - Subterra.Core.Tests.dll (net472)`.

The "Math namespace shadows System.Math" concern above is resolved.
