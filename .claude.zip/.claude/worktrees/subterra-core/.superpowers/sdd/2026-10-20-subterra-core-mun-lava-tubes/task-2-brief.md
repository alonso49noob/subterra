### Task 2: Copia de KSP de pruebas y ejecutor de escenarios

**Files:**
- Create: `tools/test-ksp.ps1`, `src/Subterra.DevTools/{TestRunner.cs,TestContext.cs,StepRegistry.cs}`, `src/Subterra.DevTools/Steps/CoreSteps.cs`, `src/Subterra.DevTools/Assertions/CoreAssertions.cs`, `tests/ksp/scenarios/smoke.cfg`

**Interfaces:**
- Produces:
  - `tools/test-ksp.ps1 -Scenario <name> -Profile <stock|full|kerbalism> [-NoBuild] [-TimeoutMin 15]` → código de salida 0 si no hay `FAIL`; copia `KSP.log`, resultados y capturas a `build/test-runs/<yyyyMMdd-HHmmss>-<scenario>-<profile>/`.
  - Formato de escenario:
    ```
    SUBTERRA_TEST { name = smoke  STEP { do = newGame  mode = SANDBOX } STEP { do = quit } }
    ```
  - `StepRegistry.Register(string doName, Func<ConfigNode, TestContext, IEnumerator> handler)`; `StepRegistry.RegisterAssertion(string what, Func<ConfigNode, TestContext, bool> check)`.
  - `TestContext.Pass(string msg)`, `TestContext.Fail(string msg)`, `TestContext.Snapshots` (`Dictionary<string, Vector3d>` de posiciones lat/lon/alt), `TestContext.ResultsDir`.
  - Pasos: `newGame mode name`, `launch craft site crew`, `teleport body lat lon alt relative=terrain|sea hold=true|false`, `release`, `wait seconds`, `waitUntil what timeout`, `eva`, `setPosition offsetUp`, `snapshot name`, `quicksave name`, `quickload name`, `warp rate seconds`, `switchTo vessel`, `camera distance`, `screenshot name`, `scene name=KSC|MainMenu`, `spike name`, `assert what …`, `quit`.
  - Aserciones base: `vesselAlive`, `vesselLanded`, `logContains text`, `noSubterraExceptions`.

- [ ] **Step 1:** `test-ksp.ps1`:
  - aborta si `Get-Process KSP_x64` tiene un proceso cuya ruta no está en `KSPTestDir`;
  - crea `C:\KSP_SubterraTest` si falta: copia los archivos de la raíz de KSP (exe, dll, `settings.cfg`, `buildID*.txt`); junction (`mklink /J`) para `KSP_x64_Data`, `GameData\Squad`, `GameData\SquadExpansion`, `Ships`;
  - perfiles como tabla: `stock` = copiar `000_Harmony`, `ModuleManager.4.2.3.dll`; `full` = stock + `Kopernicus`, `ModularFlightIntegrator`, `KSPCommunityFixes`, `ParallaxContinued`, `SCANsat`, `CommunityResourcePack` (copiados) + `Parallax_StockTerrainTextures`, `Parallax_StockScatterTextures`, `Parallax_StockPlanetTextures` (junction);
  - borra del GameData de pruebas lo que no está en el perfil (salvo junctions), copia `GameData/Subterra`, `build/DevTools/Subterra.DevTools`, `tests/ksp/scenarios/*.cfg` y `tests/ksp/cfg/*.cfg` a `GameData/Subterra.DevTools/`, escribe `GameData/Subterra.DevTools/PluginData/run.txt` = nombre del escenario;
  - lanza `KSP_x64.exe -popupwindow -screen-width 1280 -screen-height 720`, espera la línea `DONE` en `PluginData/results/<scenario>.txt` o el timeout (mata el proceso), recoge archivos, imprime el resumen.
- [ ] **Step 2:** `TestRunner` (`[KSPAddon(KSPAddon.Startup.MainMenu, false)]`, `DontDestroyOnLoad`): lee `run.txt`; si existe, carga el `SUBTERRA_TEST` con ese nombre de `GameDatabase`, ejecuta los pasos en una corrutina, escribe `PASS|FAIL <n> <do> <msg>` por paso, `DONE` al final y llama a `Application.Quit()`. Una excepción en un paso = `FAIL` y sigue con `quit`. Sin `run.txt`, no hace nada.
- [ ] **Step 3:** Pasos y aserciones base en `CoreSteps.cs`/`CoreAssertions.cs`. Datos fijados: `teleport` usa `FlightGlobals.fetch.SetVesselPosition(bodyIndex, lat, lon, alt, Vector3.zero, asl: relative == "sea", easeToSurface: false)`; `hold = true` deja la nave empaquetada (`vessel.GoOnRails()`) hasta `release`; `launch` usa `FlightDriver.StartWithNewLaunch(KSPUtil.ApplicationRootPath + "Ships/" + craft + ".craft", flagUrl, site, manifest)` con la tripulación por defecto si `crew = true`; craft de pruebas: `SPH/Crater Crawler` (tripulado, para EVA) y `SPH/Bug-E Buggy` (termómetro, focos).
- [ ] **Step 4:** `smoke.cfg`: `newGame` → `launch craft = SPH/Crater Crawler site = Runway crew = true` → `wait 5` → `teleport body = Mun lat = 0 lon = 0 alt = 3 relative = terrain` → `wait 10` → `assert what = vesselAlive` → `screenshot name = smoke` → `quit`.
- [ ] **Step 5:** `pwsh tools/test-ksp.ps1 -Scenario smoke -Profile stock` → todos `PASS`, `DONE`, captura en la carpeta del run. Repetir con `-Profile full`; si `KSP.log` informa de una dependencia que falta (p. ej. `KSPTextureLoader`, `000_KSPBurst`), añadirla al perfil `full` y repetir hasta `PASS`. Si KSP fuera de Steam no arranca, anotarlo y parar: el usuario decide.
- [ ] **Step 6:** Commit `test: add KSP test copy and scenario runner`.

