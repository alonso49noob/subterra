# Task 2 report: KSP test copy and scenario runner

Status: (filled in at the end)

## What was implemented

### `tools/test-ksp.ps1` (Windows PowerShell 5.1)
`powershell -ExecutionPolicy Bypass -File tools/test-ksp.ps1 -Scenario <name> -Profile <stock|full> [-NoBuild] [-TimeoutMin 15]`

1. Reads `KSPRefDir` / `KSPTestDir` like MSBuild does (environment variable, else `Directory.Build.props`).
2. Aborts with a clear message if any `KSP_x64` process runs from outside `KSPTestDir`
   (nothing is stopped then); a leftover test KSP (path inside `KSPTestDir`) is stopped.
3. `dotnet build Subterra.sln -c Release` unless `-NoBuild`; checks that `Subterra.dll` and
   `Subterra.DevTools.dll` exist.
4. Test copy (idempotent, safe to re-run; `robocopy` only copies changes):
   - root files `*.exe`, `*.dll`, `buildID*.txt`, `Physics.cfg` copied; `settings.cfg` copied once,
     then patched every run (`SIMULATE_IN_BACKGROUND = True`, `LOG_INSTANT_FLUSH = True`,
     `CHECK_FOR_UPDATES = False`, `MASTER_VOLUME = 0`);
   - `KSP_x64_Data`, `MonoBleedingEdge`, `Ships` and `GameData\Squad` **copied** (see deviations);
   - `GameData\SquadExpansion` and the `full` profile's Parallax texture packs are junctions
     (`cmd /c mklink /J`);
   - `saves\` created.
5. GameData made to match the profile exactly: everything not in the profile is removed —
   junctions are only unlinked (`[IO.Directory]::Delete` on the reparse point), directory trees
   are deleted by a recursive function that never follows junctions, and every `robocopy` uses
   `/XJ`. Then the profile's mods (copy or junction), `GameData\Subterra` (repo, `/MIR`),
   `GameData\Subterra.DevTools` (= `build\DevTools\Subterra.DevTools`, `/MIR`, which also wipes
   old results), `tests\ksp\scenarios\*.cfg` and `tests\ksp\cfg\*.cfg` into it, and
   `PluginData\run.txt` = scenario name (UTF-8 without BOM).
6. Launches `KSP_x64.exe -popupwindow -screen-width 1280 -screen-height 720 -logFile
   C:\KSP_SubterraTest\Player.log` (`-logFile` keeps Unity's log out of the shared
   `%USERPROFILE%\AppData\LocalLow\Squad\Kerbal Space Program\Player.log`), polls
   `PluginData\results\<scenario>.txt` every 2 s for `DONE`; on timeout (or after DONE if KSP
   has not closed within 60 s) it kills the test KSP.
7. Copies `KSP.log`, `Player.log` and everything in `results\` (results file, PNGs) to
   `build\test-runs\<yyyyMMdd-HHmmss>-<scenario>-<profile>\`, prints the result lines and
   `OK|FAILED - n PASS, m FAIL - <run dir>`. Exit code 0 only with DONE and no FAIL line.

### DevTools (`src/Subterra.DevTools`, namespace `Subterra.DevTools`)
- `TestRunner.cs` — `[KSPAddon(KSPAddon.Startup.MainMenu, false)]`, `DontDestroyOnLoad`. A
  static flag makes only the first instance run (the addon is re-created at every main-menu
  load). Reads and deletes `run.txt` (a later manual launch of the copy does nothing), waits 1 s
  real time (MainMenu.Start resets `HighLogic.CurrentGame`), finds the `SUBTERRA_TEST` node with
  that name in `GameDatabase`, runs each `STEP` in a coroutine and writes
  `PASS|FAIL <n> <do> <msg>` per step (also logged with the `[Subterra.DevTools]` prefix), then
  `DONE` and `Application.Quit()`. Steps are driven by a small pump that runs nested
  `IEnumerator`s inline and catches exceptions (Unity would swallow them): an exception =
  `FAIL … exception Type: message`, then it jumps to the scenario's `quit` step (if any), `DONE`,
  quit. A normal `FAIL` (assertion false) continues with the next step. A missing scenario
  writes `FAIL 0 load …` + `DONE`. Without `run.txt` it does nothing.
- `TestContext.cs` — `Pass(msg)`, `Fail(msg)`, `Snapshots` (`Dictionary<string, Vector3d>`, x =
  lat, y = lon, z = alt), `ResultsDir`, plus: `Detail` (assertion explanation), `Runner`,
  `QuitRequested`, tracked vessel (`Track`, `TrackedVessel` by persistentId so it survives scene
  reloads, `TrackedPartCount`), hold (`Hold`, `Release`, re-applied every frame), scene/flight
  counters fed by `GameEvents.onLevelWasLoadedGUIReady` / `onFlightReady`, and
  `WaitFor(cond, timeout, what)` / `WaitForScene` / `WaitForFlight` (throw `TimeoutException`).
- `StepRegistry.cs` — `Register(string doName, Func<ConfigNode, TestContext, IEnumerator>)`,
  `RegisterAssertion(string what, Func<ConfigNode, TestContext, bool>)` exactly as specified,
  plus `RegisterSpike(name, handler)` for the `spike` step, `GetStep/GetAssertion/GetSpike`
  (throw on unknown names; names are case-insensitive; duplicates throw). Registration is
  automatic: every class marked `[StepProvider]` has its static `Register()` called once, so
  later tasks only add files (e.g. `Spikes/PqsHoleSpike.cs`), without touching the runner.
- `Steps/CoreSteps.cs` — all 19 steps of the brief (details below).
- `Assertions/CoreAssertions.cs` — `vesselAlive`, `vesselLanded`, `logContains text`,
  `noSubterraExceptions`.
- Two small extra files: `StepArgs.cs` (ConfigNode extension methods `Arg`, `RequireArg`,
  `ArgDouble`, `ArgBool`; invariant culture; strip one pair of surrounding quotes so
  `text = "[Subterra] …"` works as written in the plan) and `LogCapture.cs`
  (`[KSPAddon(Instantly, true)]`, subscribes `Application.logMessageReceivedThreaded` as soon as
  the DevTools DLL loads, only when `run.txt` exists, so `logContains` sees messages written
  while GameData loads, before the main menu; stack traces kept only for errors).
- Deleted the placeholder `AssemblyMarker.cs`.

### `tests/ksp/scenarios/smoke.cfg`
newGame (SANDBOX) → launch `SPH/Crater Crawler` at `Runway` with crew → wait 5 → teleport Mun
lat 0 lon 0 alt 3 terrain → wait 10 → assert vesselAlive → screenshot `smoke` → quit.
(KSP's cfg parser takes one value per line, so each STEP value is on its own line.)

## How the steps work (KSP APIs)

| Step | Values (defaults) | Implementation |
|---|---|---|
| `newGame` | `mode` (SANDBOX; also SCIENCE_SANDBOX, CAREER), `name` (SubterraTest) | Deletes `saves/<name>` in the test copy, then the main menu's own sequence: `HighLogic.CurrentGame = GamePersistence.CreateNewGame(name, mode, GameParameters.GetDefaultParameters(mode, Preset.Normal), MainMenu.DefaultFlagURL, GameScenes.SPACECENTER, EditorFacility.None)`, `GameEvents.onGameNewStart.Fire()`, `HighLogic.CurrentGame.Start()`; waits for `onLevelWasLoadedGUIReady(SPACECENTER)`. |
| `launch` | `craft` (required), `site` (LaunchPad), `crew` (false) | `FlightDriver.StartWithNewLaunch(KSPUtil.ApplicationRootPath + "Ships/" + craft + ".craft", game.flagURL, site, manifest)`; manifest = `CurrentGame.CrewRoster.DefaultCrewForVessel(ConfigNode.Load(path))` when crew = true (what the launch dialog does), else `VesselCrewManifest.FromConfigNode`. Waits for `onFlightReady` + `FlightGlobals.ready` and for the vessel to go off rails, then tracks it. FAIL if crew = true and nobody boarded. |
| `teleport` | `body` (current), `lat` 0, `lon` 0, `alt` 3, `relative` terrain\|sea, `hold` false | `FlightGlobals.fetch.SetVesselPosition(GetBodyIndex(body), lat, lon, alt, Vector3.zero, asl: relative == "sea", easeToSurface: false)`, then 2 frames (KSP unpacks the active vessel one frame later). `hold = true` → `TestContext.Hold`. |
| `release` | — | Ends the hold: `Landed = false`, `OrbitPhysicsManager.HoldVesselUnpack(1)`, `GoOffRails()`; waits until unpacked. FAIL if nothing is held. |
| `wait` | `seconds` (1) | `WaitForSeconds` (game time). |
| `waitUntil` | `what`, `timeout` (30 s real) + the assertion's values | Polls the assertion every frame; FAIL with its detail on timeout. |
| `eva` | `kerbal` (first crew member in a part with an airlock) | `FlightEVA.fetch.spawnEVA(pcm, part, part.airlock, tryAllHatches: true)`; waits for the EVA vessel to be active; tracks it. |
| `setPosition` | `offsetUp` (0 m) | `vessel.SetPosition(pos + up * offsetUp)` along the local vertical, `IgnoreGForces(20)`; refuses a packed vessel. |
| `snapshot` | `name` | `Snapshots[name] = (lat, lon, alt)` of the tracked vessel. |
| `quicksave` | `name` (quicksave) | KSP's F5 path: private `QuickSaveLoad.doSave(name, msg)` via Harmony `AccessTools` (no clear-to-save refusal; the `FlightGlobals.ClearToSave()` status is reported). Checks `saves/<game>/<name>.sfs` exists. |
| `quickload` | `name` (quicksave) | KSP's F9 path: private `QuickSaveLoad.quickLoad(name, HighLogic.SaveFolder)`; waits for the next `onFlightReady` (vessel may still be packed, on purpose). |
| `warp` | `rate`, `seconds` (real) | Physics warp (`TimeWarp.Modes.LOW`) when rate is in `physicsWarpRates` (2–4), otherwise on-rails warp (`HIGH`, `warpRates`), via `TimeWarp.SetRate(index, instant)`; back to 1x and the previous mode afterwards. FAIL if KSP refused the rate. |
| `switchTo` | `vessel` (name) | Matches `GetDisplayName()` or `vesselName` (stock craft names are `#autoLOC_…` keys), prefers non-debris; `FlightGlobals.ForceSetActiveVessel` (KSP reloads the scene for unloaded vessels); waits until active; tracks it. |
| `camera` | `distance` (20) | `FlightCamera.fetch.SetDistanceImmediate` (KSP clamps to its min/max). |
| `screenshot` | `name` | At `WaitForEndOfFrame`: `Texture2D.ReadPixels` of the whole screen (UI included) → `EncodeToPNG` → `<ResultsDir>/<name>.png`. |
| `scene` | `name` = KSC\|MainMenu | Leaving flight saves `persistent` first (like the pause menu); `HighLogic.LoadScene`; waits for the scene. |
| `spike` | `name` + the spike's values | Runs the handler registered with `StepRegistry.RegisterSpike`. |
| `assert` | `what` + the assertion's values | PASS/FAIL with the assertion's `Detail`. |
| `quit` | — | Stops the scenario; the runner writes DONE and calls `Application.Quit()`. |

Assertions: `vesselAlive` = the tracked vessel (set by launch/eva/switchTo, found again by
persistentId after reloads; active vessel if none) exists, `state != DEAD`, and has at least the
part count it had when tracked; `vesselLanded` = `vessel.Landed`; `logContains text` = a captured
log message contains the text (ordinal); `noSubterraExceptions` = no `Exception` log entry (nor
an Error/Assert entry containing "Exception") whose message or stack trace mentions "Subterra".

Hold (used later by `teleportToNetwork … hold = true`): every frame while held, the runner calls
`OrbitPhysicsManager.HoldVesselUnpack(60)` and keeps the vessel packed with `Landed = true`
(`GoOnRails()`, or orbit driver set to `IDLE` if already packed). A packed landed vessel has an
idle orbit driver, so KSP pins it at its latitude/longitude/altitude (`VesselPrecalculate.SetLandedPosRot`)
instead of letting it fall along its orbit. Verified: held 20 m above the Mun for 5 s (altimeter
2651 m vs. 2632 m terrain), then fell and landed after release.

## Deviations from the brief (and why)

1. **`KSP_x64_Data` and `GameData\Squad` are copied, not junctioned** (brief/R10 said junction;
   R10's premise was that they are read-only, and they are not):
   - KSPBurst (needed by the `full` profile) writes `Application.dataPath/Plugins/lib_burst_generated.*`
     (decompiled `KSPBurst.dll`: `OutputLibrary = Path.Combine(DataDir, "Plugins", "lib_burst_generated")`).
     The copy uses `robocopy /MIR /XF lib_burst_generated.*`, so the user's burst library is never
     copied and the test copy's own one is never purged.
   - Stock KSP's asset loader (`KSPAssets.dll`, AssetLoader) extracts the platform dependency
     bundle and rewrites `GameData\Squad\squadcorefx.ksp` and `GameData\Squad\KSPedia\squadcorefx.ksp`
     on every start. **My first smoke run still had `Squad` as a junction, so it rewrote these two
     files in the user's install** (13:49:56 and 13:49:58). Content is unchanged: MD5
     `f73c9fac4de92589a0d7799e9901ee79` for both, identical to the files the test copy now
     regenerates itself; only the modification time changed (the user's own KSP rewrites them
     the same way at each launch). Since switching Squad to a copy, a
     `find <KSP install> -newermt …` after each run shows nothing new.
   - Cost: ~4.6 GB in `C:\KSP_SubterraTest` (3.4 GB KSP_x64_Data + 1.1 GB Squad), copied once;
     later runs only compare timestamps (setup ~10 s).
   - `SquadExpansion` stays a junction (nothing is written there: checked after every run), as do
     the Parallax texture packs in `full`.
2. `MonoBleedingEdge` (Unity's Mono runtime, 6 MB) is copied too — KSP does not start without it.
3. Removal of entries not in the profile also unlinks junctions (only the link) instead of keeping
   them, so switching `full` → `stock` does not leave 3.5 GB of Parallax textures in stock GameData.
4. Extra launch argument `-logFile C:\KSP_SubterraTest\Player.log`, so the test run does not
   overwrite the user's `Player.log`/`Player-prev.log` in LocalLow.
5. `settings.cfg` overrides limited to what KSP actually honours at start (see concerns about
   screen size and language).

## Concerns / notes for later tasks

- **Screen size**: KSP ignores `-screen-width 1280 -screen-height 720` here: Unity takes the
  window from its saved PlayerPrefs (`HKCU\Software\Squad\Kerbal Space Program`, shared with the
  user's install: 1920x1080, fullscreen-window), and KSP does not apply settings.cfg's resolution
  at start. Runs therefore cover the screen and screenshots are 1920x1080. Forcing 1280x720
  (`-screen-fullscreen 0`) would make Unity save 1280x720 windowed into those shared prefs, i.e.
  change the user's own game window on its next start, so I left the brief's flags as they are
  (Unity rewrites the same values; checked the registry after the runs). If a fixed size is
  wanted, the script would have to save and restore those registry values around the run.
- **Language**: KSP takes the language from `buildID64.txt` (`language = es-es` in this Steam
  install), and the install only contains the `es-es` dictionary (`GameData/Squad/Localization`),
  so the test copy runs in Spanish (part titles like "Lata de Aterrizaje Mk1"; the test craft
  keep their names "Crater Crawler" / "Bug-E Buggy"). Forcing `en-us` was tried and leaves raw
  `#autoLOC_…` keys, so it was reverted. Task 29's `biomeDisplayName` check must not rely on an
  English KSP (a literal display name works in any language).
- **Night on the Mun**: at UT ≈ 0 the point lat 0 / lon 0 of the Mun is dark; the smoke
  screenshot shows the rover only when brightened (navball level, altimeter 2632 m, "Superficie"
  speed mode). Task 27's `setNoon` (or another longitude) will help screenshots.
- `teleport` passes `alt` to `SetVesselPosition`, which uses `Math.Abs(alt)`: `alt = -95` (the
  underground spike, Task 5) becomes +95. That spike will need its own placement.
- A vessel saved while held is saved as LANDED (the hold sets `Landed`); do not quicksave while
  holding. Faking `Landed` also fires the "Landing" progress node (harmless in SANDBOX; would
  count in CAREER). `release` restarts the frozen orbit at rest relative to the surface (without
  that, the first version released the rover with the speed of a 5 s fall: 3.1 s instead of 4.8 s
  to land from 20 m). Between `SetVesselPosition` and the hold KSP unpacks the vessel for about
  2 physics frames (~70 ms in the log).
- On-rails `warp` can be refused by KSP (e.g. right after moving, "moving over surface"): the step
  then FAILs with the clear-to-save status and surface speed instead of waiting.
- `logContains` only sees messages logged after the DevTools assembly loads (KSPAddon Instantly),
  i.e. not the assembly loader's own first lines; everything from ModuleManager/GameDatabase on is
  captured.
- First run of a fresh copy copies ~4.6 GB (about 1 min here); KSP regenerates drag cubes on each
  start (`PartDatabase.cfg` is rewritten), stock profile: ~60 s to the main menu, smoke ~2.5 min
  end to end.

## Profiles (final)

- `stock` (copied): `000_Harmony`, `ModuleManager.4.2.3.dll`
- `full` (copied): `000_Harmony`, `ModuleManager.4.2.3.dll`, `Kopernicus`, `ModularFlightIntegrator`,
  `KSPCommunityFixes` (without its `PluginData\TextureCache`), `ParallaxContinued`, `SCANsat`,
  `CommunityResourcePack`, **`KSPTextureLoader`**, **`000_KSPBurst`** (added);
  (junction): `Parallax_StockTerrainTextures`, `Parallax_StockScatterTextures`, `Parallax_StockPlanetTextures`
- every profile: `Squad` (copied), `SquadExpansion` (junction), `Subterra`, `Subterra.DevTools` (repo)

Evidence for the two additions (first `full` run, KSP.log, run dir `build/test-runs/20261020-140307-smoke-full`):
```
[WRN 14:03:13.201] AssemblyLoader: Assembly 'Kopernicus' has not met dependency 'KSPTextureLoader' V1.0.26
[WRN 14:03:13.201] AssemblyLoader: Assembly 'Parallax' has not met dependency 'KSPBurst' V1.0.0
```
(I stopped that test KSP once those lines appeared; Kopernicus and Parallax would not have
loaded.) Remaining warnings in the final `full` log also appear in the user's own KSP.log and
are optional integrations: `Kopernicus.KSCScatterMask.BurstPQS` needs `BurstPQS`, `SCANmechjeb`
needs `MechJeb2`, `ADDON BINDER: Cannot resolve assembly: System.Runtime / SCANsat.Unity`.
Parallax throws 3 NullReferenceExceptions in its own `OnDestroy`/`OnDisable` while KSP quits
(not ours, no Subterra frames).

## Commands run and results

`dotnet build Subterra.sln -c Release` → `Compilación correcta. 0 Advertencia(s) 0 Errores`.

KSP launched outside Steam without problems: `SteamManager` only initialises Steam when
`<KSP root>/../../appmanifest_220200.acf` exists, which is not the case for `C:\KSP_SubterraTest`.

### Smoke, stock — `powershell -ExecutionPolicy Bypass -File tools/test-ksp.ps1 -Scenario smoke -Profile stock -TimeoutMin 12` → exit 0
Run dir `build/test-runs/20261020-134925-smoke-stock` (first run, Squad still a junction; final run below):
```
PASS 1 newGame SANDBOX save 'SubterraTest' at the Space Center
PASS 2 launch #autoLOC_501182 at Runway: 115 parts, 1 crew
PASS 3 wait
PASS 4 teleport Mun lat 0 lon 0 alt 3 m over terrain
PASS 5 wait
PASS 6 assert vesselAlive: #autoLOC_501182: 115/115 parts, LANDED, altitude 2632.2 m
PASS 7 screenshot smoke.png 1920x1080
PASS 8 quit
DONE
OK - 8 PASS, 0 FAIL - ...\build\test-runs\20261020-134925-smoke-stock
```
(After this run messages use `GetDisplayName()` and mention the body.) Screenshot: dark (night
at lon 0), brightened crop shows the Crater Crawler upright on its wheels on Mun terrain;
navball level, altimeter 2632 m.

### Smoke, full
- `… -Scenario smoke -Profile full -TimeoutMin 20` with the brief's list → KSP.log reported the
  two missing dependencies (above); test KSP stopped; script printed
  `KSP exited without DONE (exit code -1); see KSP.log` / `FAILED - 0 PASS, 0 FAIL` (exit 1).
- After adding `KSPTextureLoader` and `000_KSPBurst`: `… -Scenario smoke -Profile full -TimeoutMin 25`
  → exit 0, run dir `build/test-runs/20261020-140339-smoke-full`:
```
PASS 1 newGame SANDBOX save 'SubterraTest' at the Space Center
PASS 2 launch Crater Crawler at Runway: 115 parts, 1 crew
PASS 3 wait
PASS 4 teleport Mun lat 0 lon 0 alt 3 m over terrain
PASS 5 wait
PASS 6 assert vesselAlive: Crater Crawler: 115/115 parts, PRELAUNCH at Mun, altitude 2633.2 m
PASS 7 screenshot smoke.png 1920x1080
PASS 8 quit
DONE
OK - 8 PASS, 0 FAIL - ...\build\test-runs\20261020-140339-smoke-full
```
  Screenshot (brightened): the rover among Parallax rock scatters on the Mun, surface speed
  0.0 m/s, altimeter 2633 m. KSPBurst compiled into the test copy
  (`C:\KSP_SubterraTest\KSP_x64_Data\Plugins\lib_burst_generated.dll`, 14:04); the user's
  `lib_burst_generated.*` keep their 2026-10-17 timestamps.

### Exercising every step (temporary scenario, not committed)
A throwaway `tests/ksp/scenarios/devsteps.cfg` (deleted before the commit) ran every core step
in the stock profile: newGame, launch (Crater Crawler, then Bug-E Buggy from the KSC), teleport
with hold, snapshot, screenshot, release, waitUntil, wait, assert (vesselAlive, vesselLanded via
waitUntil, logContains positive and negative, noSubterraExceptions), camera, eva, setPosition,
quicksave, quickload, switchTo, warp (physics x4 and on-rails x1000), scene KSC and MainMenu,
an unknown spike (exception path → jumps to quit) and quit.

## Self-review

- Brief coverage: script options/behaviour, profile table, runner (MainMenu addon,
  DontDestroyOnLoad, run.txt, GameDatabase lookup, per-step lines, DONE, Application.Quit,
  exception → FAIL → quit, no-op without run.txt), the 19 steps, the 4 assertions, smoke.cfg,
  fixed APIs (`SetVesselPosition(…, Vector3.zero, asl: relative == "sea", easeToSurface: false)`,
  `GoOnRails` for hold, `StartWithNewLaunch(ApplicationRootPath + "Ships/" + craft + ".craft", …)`),
  `StepRegistry.Register/RegisterAssertion` and `TestContext.Pass/Fail/Snapshots/ResultsDir`
  signatures exactly as specified. Deviations are listed above with reasons.
- Never writes into the user's install: KSP_x64_Data and Squad copied; junctions only for
  SquadExpansion and the Parallax packs; junctions are only ever unlinked; robocopy `/XJ`; after
  every run since 13:50 `find "<KSP install>" -newermt "2026-10-20 13:50"` lists nothing. The
  user's KSP is never stopped (the script refuses to run instead). The one write that happened
  (first run, two `squadcorefx.ksp` files rewritten with identical bytes) is described above.
- Idempotent: every run re-syncs root files, data folders and GameData (robocopy copies only
  changes; profile switches full → stock → full verified; the test copy's own
  `lib_burst_generated.*` survive `/MIR` thanks to `/XF`); `newGame` deletes the save it creates.
- Pristine repo: build outputs (`GameData/Subterra/Plugins/*.dll`, `build/`) and run artifacts
  (`build/test-runs/`) are git-ignored; the temporary scenario was deleted before committing.
- YAGNI: no `kerbalism` profile yet (Task 32 adds it; an unknown profile fails with the list of
  known ones); removed unused context members (step number/name).
