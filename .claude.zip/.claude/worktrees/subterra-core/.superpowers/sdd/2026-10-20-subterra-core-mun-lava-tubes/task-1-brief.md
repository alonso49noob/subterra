### Task 1: Solución y proyecto de pruebas del núcleo

**Files:**
- Create: `Directory.Build.props`, `Subterra.sln`, `src/Subterra.Core/Subterra.Core.csproj`, `src/Subterra/Subterra.csproj`, `src/Subterra.DevTools/Subterra.DevTools.csproj`, `tests/Subterra.Core.Tests/Subterra.Core.Tests.csproj`, `tests/Subterra.Core.Tests/SmokeTests.cs`

**Interfaces:**
- Produces: propiedades MSBuild `KSPRefDir`, `KSPManaged`, `HarmonyDll`, `KSPTestDir`; el build de `Subterra` copia `Subterra.dll` y `Subterra.Core.dll` a `GameData/Subterra/Plugins/`; el de DevTools copia a `build/DevTools/Subterra.DevTools/Plugins/`.

- [ ] **Step 1:** `Directory.Build.props` como el de proj4 (`C:\proj4\Directory.Build.props`), pero con `KSPRefDir` (por defecto la instalación de Steam, solo referencias) y `KSPTestDir` (por defecto `C:\KSP_SubterraTest`). Csproj de plugin y DevTools con las mismas referencias que `C:\proj4\src\ReusabilityLink\ReusabilityLink.csproj` (Assembly-CSharp, firstpass, UnityEngine, CoreModule, IMGUIModule, InputLegacyModule, PhysicsModule, AnimationModule, TextRenderingModule, ImageConversionModule, 0Harmony), `Private=false`. Tests con Microsoft.NET.Test.Sdk 17.11.1, xunit 2.9.2, xunit.runner.visualstudio 2.8.2.
- [ ] **Step 2:** Prueba `SmokeTests.CoreAssemblyHasNoUnityReference`: `Assert.DoesNotContain(typeof(Subterra.Core.Math.Vec3).Assembly.GetReferencedAssemblies(), a => a.Name.StartsWith("UnityEngine"))` (crea `Vec3` vacío para que compile).
- [ ] **Step 3:** `dotnet build Subterra.sln -c Release` → 0 errores; `dotnet test tests/Subterra.Core.Tests -c Release` → 1 PASS.
- [ ] **Step 4:** Commit `chore: scaffold Subterra solution`.

