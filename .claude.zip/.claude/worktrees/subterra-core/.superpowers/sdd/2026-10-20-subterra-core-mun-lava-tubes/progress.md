# SDD ledger — plan: docs/superpowers/plans/2026-10-20-subterra-core-mun-lava-tubes.md

Spec: docs/superpowers/specs/2026-10-20-subterra-core-mun-lava-tubes-design.md
Worktree: C:\proj5\.claude\worktrees\subterra-core (branch worktree-subterra-core), base 0209091
Env: Windows PowerShell 5.1 only (no pwsh); 16 cores; net472 ref assemblies in NuGet cache; Python 3.14 + numpy + Pillow.

## Pre-flight scan

### Task pairs sharing files / interfaces
| Tasks | Producer → consumer | Finding |
|---|---|---|
| T1↔T2 | KSPTestDir/KSPRefDir props → test-ksp.ps1 | consistent |
| T2↔T32 | ps1 profile table → kerbalism profile | T32 lists ps1 in Files: ok |
| T2↔T33 | ps1 deploy → build.py --install | T33 text changes ps1 but Files omits it → R2 |
| T2↔T37 | ps1 profiles → stock+Kopernicus profile | T37 Files omits ps1 → R2 |
| T3/T4/T5→T6→T23/T24/T25/T34 | m0-findings.md → shader mode, hole method, order, instancing | consistent |
| T7→all core | Vec3/Vec3d/Aabb/Hash/Rng/Noise | consistent |
| T8→T10–T20,T29–T31,T34,T36 | model names (EdgeSpec.BenchHeight cfg key `bench`, ScatterSpec.Lod0/1Distance, EnrichmentSpec.Zone ZoneKind?) | consistent |
| T9→T10,T12,T14,T22 | BodyFrame, IHeightSampler, PrecomputedSamples, GridSamples | consistent |
| T10→T12 | TubePath.SamplePoints/Build → RequiredSamples/Compile | consistent |
| T11→T12,T16,T17,T23 | NetworkSdf (Distance, ForRegion, Roughness) | consistent |
| T12→T15,T22–T31 | TubeNetwork/Skylight/ZoneInfo | consistent |
| T13→T14,T15,T22 | CellGrid/CellId | consistent |
| T14→T31 | id `<idPrefix>-NNNN`; T31 asserts "MN-" but DevMun.cfg (T21) sets no idPrefix → default "MU" | conflict → R3 |
| T16→T18,T20,T23,T26,T34 | MeshData | consistent |
| T17→T20 | ChunkKey (T17 precedes T20) | consistent |
| T19→T21,T27,T28 | Strata/Geotherm; T28 expects 250.3 K at 70 m with T36 table | consistent |
| T20→T34 | ScatterPlacer/Merger | consistent |
| T21→T23,T26,T31,T35 | Settings fields | consistent |
| T21→T30,T34 | DevMun.cfg edits; T30 Files omits DevMun.cfg | → R2 |
| T21↔T36 | DevMun.cfg + Mun.cfg both `body = Mun` once T36 lands; boot expects "1 sites, 1 fields" | conflict → R4 |
| T22→T23+ | teleportToNetwork, SubterraClock | consistent |
| T23→T24,T34 | ChunkStreamer.CollidersReady; T34 modifies streamer | consistent |
| T24→T27 | UndergroundState / VesselModule (T27 fills env fields) | consistent |
| T25→T26 | skylights → rim/caps | consistent |
| T29↔T21 | biomeDisplayName "Dev Tube" needs a display source for dev site | → R5 |
| T31 | asserts logContains "Discovered: …" but only a screen message is specified | → R6 |

### Per-task self-consistency
| Task | Finding |
|---|---|
| T1 | ok; worktree dirs under .claude/ show as untracked in main checkout → R7 |
| T2 | plan says `pwsh`; machine has only Windows PowerShell 5.1 → R1 |
| T3–T6 | ok |
| T7 | RngRangeBounds uses InRange(v,-3,4.999999) — can spuriously fail for v∈(4.999999,5) → R8 |
| T8 | ok (Range struct value equality) |
| T9–T10 | ok (200000−95−60; roof 0.08×200=16) |
| T11 | hand-checked bench/flat-floor/shaft test points against the formula: consistent |
| T12–T20 | ok (N=7 → 294 cells; T19 250.4 K; T20 dropped 35) |
| T21–T28 | ok apart from rows above |
| T29–T37 | ok apart from rows above |

### Rulings
- Ruling R1: every `pwsh tools/test-ksp.ps1 …` means `powershell -ExecutionPolicy Bypass -File tools/test-ksp.ps1 …`; the script must be Windows PowerShell 5.1 compatible — only PS 5.1 exists here — cost if wrong: none (pwsh would also run a 5.1 script).
- Ruling R2: tasks may edit `tools/test-ksp.ps1` (T33, T37) and `tests/ksp/cfg/DevMun.cfg` (T30) although their Files lists omit them — the task text requires those edits — cost if wrong: none.
- Ruling R3: `DevMun.cfg` sets `idPrefix = MN` — T31/spec use "MN-0427" ids — cost if wrong: trivial cfg edit.
- Ruling R4: the loader merges several `SUBTERRA_BODY` nodes for the same body (lists appended; scalars and GEOTHERM/STRATA from the first node that sets them) and logs one "Loaded body …" line with merged counts; T36 updates `boot.cfg` expected counts — spec §11 wants robustness and third-party add-on cfgs are likely — cost if wrong: small loader rework.
- Ruling R5: a named site's biome display name = `Localizer.Format(site.DisplayName)` when DisplayName is set (literal or `#` key), else `#Subterra_Site_<id>`; DevMun.cfg uses `displayName = Dev Tube` — cost if wrong: trivial.
- Ruling R6: DiscoveryService also writes `Log.Info("Discovered: lava tube network <id>")` so the scenario can assert it — cost if wrong: none.
- Ruling R7: T1 adds `.claude/` to `.gitignore` — keeps the main checkout clean of worktree dirs — cost if wrong: none.
- Ruling R8: T7 RngRangeBounds asserts `v >= -3.0 && v < 5.0` instead of InRange(…, 4.999999) — matches the exclusive-max contract — cost if wrong: none.

## Progress
- Ruling R9: rename core namespace/folder `Subterra.Core.Math` → `Subterra.Core.Numerics` (`src/Subterra.Core/Numerics/`), and the plugin uses one flat namespace `Subterra` for every file regardless of folder — avoids shadowing System.Math / System.Environment (plugin folder Environment/) — plan paths `Math/` read as `Numerics/` from now on — cost if wrong: trivial rename.
Task 1: BASE 0209091; implementer a32649e5391ac427a; head 92d81df; review: spec ✅, Important (plan-mandated) Math-namespace shadowing → R9
Task 1: minor (deferred): smoke test checks only UnityEngine prefix (could add Assembly-CSharp)
Task 1: minor (deferred): Reference block duplicated in Subterra.csproj and DevTools.csproj (shared props later?)
Task 1: fix round 1/5 (2 addressed, 0 open — Math→Numerics rename, smoke test rejects Assembly-CSharp; commits 92d81df..5256d0d)
Task 1: complete (commits 0209091..5256d0d, review clean)
Task 1: minor (deferred): smoke predicate does not reject 0Harmony
- Ruling R10: the test copy COPIES `Ships/` (or only the needed craft files) instead of junctioning it; junctions only for read-only `KSP_x64_Data`, `GameData/Squad`, `GameData/SquadExpansion` and big texture packs — avoids any write-through into the user's install — cost if wrong: a few MB of disk.
Task 2: BASE 5256d0d
Task 2: implementer a6a26edbf3571285d (opus, background)
