### Task 3: Prueba rápida — agujero en el PQS

**Files:**
- Create: `src/Subterra.DevTools/Spikes/PqsHoleSpike.cs`, `tests/ksp/scenarios/m0-hole.cfg`, `docs/superpowers/notes/m0-findings.md` (sección "PQS hole")

**Interfaces:**
- Produces (para Task 25): método de inyección de PQSMods en tiempo de ejecución que funciona, `order` necesario frente a Parallax, y espaciado real entre vértices del PQS de la Mun.

- [ ] **Step 1:** Spike `PqsHole`: crea `SpikeHoleMod : PQSMod` como hijo de `body.pqsController.transform`, `sphere = pqs`, `order` del parámetro; llama al privado `PQS.SetupMods` con `AccessTools.Method(typeof(PQS), "SetupMods")` y luego `pqs.RebuildSphere()`. En `OnQuadBuilt` quita los triángulos con algún vértice a < 60 m del centro (coordenadas locales del PQS) y reasigna `quad.meshCollider.sharedMesh` (null y luego `quad.mesh`) si existe. Postfix Harmony en el privado `PQ.UpdateVisibility` que vuelve a cortar si `mesh.triangles.Length` difiere del recuento cortado.
- [ ] **Step 2:** Medidas que escribe el spike: `pqs.maxLevel`; distancia entre vértices adyacentes del quad de mayor nivel junto a la nave; orden (`order`) de cada PQSMod del cuerpo (incluido el de Parallax si está); triángulos dentro del radio en quads visibles; raycast desde 50 m sobre el centro hacia abajo (máscara `1 << 15`, 500 m); número de GameObjects de la capa 15 que no son quads dentro del cilindro del agujero (colisores de scatters de Parallax).
- [ ] **Step 3:** `m0-hole.cfg`: `launch` → `teleport` a Mun lat 0 lon 0 alt 3 → `wait 10` → `spike name = PqsHole order = 50` → `wait 5` → `screenshot hole-near` → `teleport` a 2 km (lon + 0.6) → `wait 10` → `teleport` de vuelta → `wait 10` → `spike name = PqsHoleMeasure` → `camera distance = 30` → `screenshot hole-after` → `quit`.
- [ ] **Step 4:** Ejecutar con `stock` y `full`. Criterios: 0 triángulos dentro del radio tras volver; raycast sin impacto; con `full`, 0 colisores de scatter dentro del agujero. Revisar las capturas (leer los PNG).
- [ ] **Step 5:** Anotar resultados en `m0-findings.md` (valores medidos, `order` de Parallax, si pasa o qué alternativa se propone). Commit `spike: PQS hole`.

